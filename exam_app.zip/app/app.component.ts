import { Component } from '@angular/core';

import { Platform, NavController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';


import { Router, NavigationExtras } from '@angular/router';

import { AuthService } from './services/auth.service';
 import { Storage } from '@ionic/storage';
 
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
    
})
export class AppComponent {
  constructor(
    private platform: Platform,public storage: Storage ,
    private splashScreen: SplashScreen, 
	private authService: AuthService,
    private statusBar: StatusBar,
  private router: Router,
  private navCtrl: NavController
  ) {



    let cat1=parseFloat(window.localStorage.getItem("category_status"))
    if(window.localStorage.getItem("mobile")!=null){
      this.authService.isLoggedIn=true;
      let form={};
      form['otp']=window.localStorage.getItem("otp")
      if(cat1 >0){
          let navigationExtras: NavigationExtras = {
          queryParams: {
          special: 2
          }
          };
          this.navCtrl.navigateRoot(['exam2'], navigationExtras);    
      }
    
      if(cat1==0){
            this.navCtrl.navigateRoot(['exam']);
      }
    }
    else{
      this.navCtrl.navigateRoot('/login');


    }



    

    this.initializeApp();
  }



 user = {
    name: 'Simon Grimm',
    website: 'www.ionicacademy.com',
    address: {
      zip: 48149,
      city: 'Muenster',
      country: 'DE'
    },
    interests: [
      'Ionic', 'Angular', 'YouTube', 'Sports'
    ]
  };
  
  
  
  initializeApp() {


    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
	  
    });
  }
  
  sendto(page) {
    console.log(page);
    // alert(page)
    this.router.navigate([page]);
    console.log(page);
  }
  opentests(page) { 
 
 
   
   let navigationExtras: NavigationExtras = {
      queryParams: {
        special: 2
      }
    };
    this.router.navigate(['exam2'], navigationExtras);
	
	
	
	
	//  this.router.navigate(['exam2'], navigationExtras);
  }
  
  openLogin() {
    
        this.router.navigate(['login']);
    
  }
  
  openDepositHistory() {
    
        this.router.navigate(['deposit']);
    
  }
  
  
  openTransactionHistory() {
    
        this.router.navigate(['transactionhistory']);
    
  }
  
  
  openRechargeHistory() {
    
        this.router.navigate(['rechargehistory']);
    
  }
  
  
  openDepositPayment() {
    
        this.router.navigate(['depositform']);
    
  }
  
  openUtility() {
    
        this.router.navigate(['utility']);
    
  }
  
  
  openPostpaid() {
    
        this.router.navigate(['postpaid']);
    
  }
  
  openPrepaid() {
    
        this.router.navigate(['prepaid']);
    
  }
  
   
  sendtoSM()
  { 


  }
 
  
  
  logout() {
    

    // window.localStorage.removeItem("mobile"); 
    // window.localStorage.removeItem("token"); 
    // window.localStorage.removeItem("category_status"); 
    
    window.localStorage.clear()
    // .then(() => {
      console.log('all keys cleared');
    //  this.router.navigate(['login']);
    this.navCtrl.navigateRoot('/login');
    
    
       
      // });
  }
  
   
}
