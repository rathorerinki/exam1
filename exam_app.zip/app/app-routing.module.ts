import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth/auth.guard';
import { Exam2Page } from './exam2/exam2.page';
 

const routes: Routes = [
   { path: 'home', redirectTo: 'exam2', pathMatch: 'full' },  
  { path: 'login', loadChildren: './auth/login/login.module#LoginPageModule' },
  { path: 'register', loadChildren: './auth/register/register.module#RegisterPageModule' },
  // { path: '', redirectTo: 'login', pathMatch: 'full' },  
  { path: '', component: Exam2Page },

 
  { path: 'answersheet', loadChildren: './answersheet/answersheet.module#AnswersheetPageModule' , canActivate: [AuthGuard] },
 
  
  { path: 'exam2', loadChildren: './exam2/exam2.module#Exam2PageModule' , canActivate: [AuthGuard] },
  { path: 'showexam', loadChildren: './showexam/showexam.module#ShowexamPageModule' , canActivate: [AuthGuard] },
  { path: 'marks', loadChildren: './marks/marks.module#MarksPageModule' , canActivate: [AuthGuard] },
  { path: 'instructions', loadChildren: './instructions/instructions.module#InstructionsPageModule' },
  { path: 'result', loadChildren: './result/result.module#ResultPageModule' , canActivate: [AuthGuard] },
    { path: 'category', loadChildren: './category/category.module#CategoryPageModule' , canActivate: [AuthGuard] },
	
	{ path: 'questionreview', loadChildren: './questionreview/questionreview.module#QuestionreviewPageModule' , canActivate: [AuthGuard]},
  { path: 'about-application', loadChildren: './about-application/about-application.module#AboutApplicationPageModule' , canActivate: [AuthGuard] },
  { path: 'supportcontact', loadChildren: './supportcontact/supportcontact.module#SupportcontactPageModule' , canActivate: [AuthGuard] },
  { path: 'summery', loadChildren: './summery/summery.module#SummeryPageModule', canActivate: [AuthGuard]  },
  //{ path: 'slider', loadChildren: './slider/slider.module#SliderPageModule', canActivate: [AuthGuard]  },
  { path: 'faq', loadChildren: './faq/faq.module#FAQPageModule', canActivate: [AuthGuard]  },
  { path: 'livesupport', loadChildren: './livesupport/livesupport.module#LivesupportPageModule', canActivate: [AuthGuard]  },
  { path: 'feedback', loadChildren: './feedback/feedback.module#FeedbackPageModule' , canActivate: [AuthGuard] },
  { path: 'profile', loadChildren: './profile/profile.module#ProfilePageModule', canActivate: [AuthGuard]  },
  { path: 'questionsummery', loadChildren: './questionsummery/questionsummery.module#QuestionsummeryPageModule' , canActivate: [AuthGuard] },
  { path: 'exam', loadChildren: './exam/exam.module#ExamPageModule' , canActivate: [AuthGuard] },
  { path: 'tests', loadChildren: './tests/tests.module#TestsPageModule' , canActivate: [AuthGuard]  },
  { path: 'chat', loadChildren: './chat/chat.module#ChatPageModule' , canActivate: [AuthGuard] },
];


@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
