 
import { Component, OnInit } from '@angular/core';

import { ActionSheetController } from '@ionic/angular';
import { AuthService } from '../services/auth.service';
import { Result } from '../model/result';
import { Storage } from '@ionic/storage';
import { ActivatedRoute, Router } from '@angular/router';

import { Test } from '../model/test';
 

@Component({
selector: 'app-tests',
  templateUrl: './tests.page.html',
  styleUrls: ['./tests.page.scss'],
})
export class TestsPage implements OnInit {
 

tests: Test[];

 
  async openMenu(test_id,test_name,attempt_id) {
    const actionSheet = await this.actionSheetController.create({
      header: '',
    mode:'ios',
      buttons: [{
        text: 'Reattempt',
        
        handler: () => {
      
        
     this.router.navigate(['instructions'],  { queryParams: { special: test_id} });
     
        }
      }, {
        text: 'Review',
        icon: '',
        handler: () => {
           this.router.navigate(['questionreview'],  { queryParams: { special: test_id, special1: test_name,special2: attempt_id} });
        }
      }, {
        text: 'Cancel',
        icon: 'close',
        role: 'cancel',
        handler: () => {
          console.log('Cancel clicked');
        }
      }]
    });
    await actionSheet.present();
  }

  constructor(public actionSheetController: ActionSheetController, private  authService:  AuthService,
  private  router:  Router,public storage: Storage,private route: ActivatedRoute ) { }
   
  

  ngOnInit() {
	  
  

    this.authService.getTests( )
   
      .subscribe(data => {
        
         this.tests = data;
      });
     

	   

}
  
    

      sendtoTest(test_id,t_name,paid,topen) {
 
 
 if(parseInt(paid)==1){


      alert("Please Contact to center")

      }

else
      if(parseInt(topen) > 0){


      alert("Please Contact to center")
     
      }

  else  {

  


   this.router.navigate(['instructions'],  { queryParams: { special: test_id, special1:t_name} });
           
     
 
  }
  
 
    } 
  
}
