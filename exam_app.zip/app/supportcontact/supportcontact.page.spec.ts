import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupportcontactPage } from './supportcontact.page';

describe('SupportcontactPage', () => {
  let component: SupportcontactPage;
  let fixture: ComponentFixture<SupportcontactPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupportcontactPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupportcontactPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
