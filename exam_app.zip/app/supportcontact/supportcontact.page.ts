import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supportcontact',
  templateUrl: './supportcontact.page.html',
  styleUrls: ['./supportcontact.page.scss'],
})
export class SupportcontactPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
