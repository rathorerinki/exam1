import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-questionsummery',
  templateUrl: './questionsummery.page.html',
  styleUrls: ['./questionsummery.page.scss'],
})
export class QuestionsummeryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
