export class Transaction {
  
    TxnID: string;
    CR: string; 
	 DR: string;
    datentime: string; 
	 Username: string;
    number: string; 
	 operator: string;
    status: string; 


}