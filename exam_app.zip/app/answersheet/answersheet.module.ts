import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AnswersheetPageRoutingModule } from './answersheet-routing.module';

import { AnswersheetPage } from './answersheet.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AnswersheetPageRoutingModule
  ],
  declarations: [AnswersheetPage]
})
export class AnswersheetPageModule {}
