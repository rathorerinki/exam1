import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AnswersheetPage } from './answersheet.page';

describe('AnswersheetPage', () => {
  let component: AnswersheetPage;
  let fixture: ComponentFixture<AnswersheetPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnswersheetPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AnswersheetPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
