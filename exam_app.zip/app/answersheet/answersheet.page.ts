import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ModalController } from '@ionic/angular';

import { Answer } from '../model/answer';
import { Question } from '../model/questions';
import { testsummery } from '../model/testsummery';




@Component({
  selector: 'app-answersheet',
  templateUrl: './answersheet.page.html',
  styleUrls: ['./answersheet.page.scss'],
})
export class AnswersheetPage implements OnInit {
paramas;
answer : Answer[];
questions:Question[];
testsummery:testsummery[];


 constructor(private  authService:  AuthService,
 public viewCtrl: ModalController,
  private  router:  Router) { }

  ngOnInit() {
	  
	  
	  	/*
	  console.log("loading answer  ngOnInit  42 ");
      this.authService.getAnswer( "all" )
      .subscribe(answer => {
        console.log(answer);
         this.answer= answer; 
		 console.log("loading answer ngOnInit  42 ");
      });*/
	  
	    console.log("loading questions  ngOnInit  42 ");
        this.authService.getQuestions( "all" )
      .subscribe(questions => {
        console.log(questions);
         this.questions = questions; 
		 console.log("loading questions ngOnInit  42 ");
      });
	  
	  /*console.log("loading testsummery  ngOnInit  42 ");
	 
        this.authService.testsummery( "all")
      .subscribe(testsummery => {
        console.log(testsummery);
         this.testsummery = testsummery; 
		 console.log("loading testsummery ngOnInit  42 ");
		  //alert("test");
      });
	  */
	  
	  
  }
  
  dismiss() {
	//alert("dismiss");
  this.viewCtrl.dismiss({'dismissed': true});

}
  sendto(page) {
    console.log(page);
        this.router.navigate([page]);
    
  }

}