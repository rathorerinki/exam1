import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
 import { Storage } from '@ionic/storage';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  loginForm: FormGroup;
  loginForm1: FormGroup;
  mobile1;
  hideMe= false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,public storage: Storage,
    private authService: AuthService,
    public toastController: ToastController) { }

  ngOnInit() {  

      this.loginForm = this.formBuilder.group({
      'mobile' : [null, Validators.required],
     

    });

     
    this.loginForm1 = this.formBuilder.group({
      'otp' : [null, Validators.required]
    
    });
  

  }







  onFormSubmit(form: NgForm) {
    this.authService.login(form)
      .subscribe(res => {
		  
		  alert(res.otp)
		  	 
        if (!res.Error) { 
          
          window.localStorage.setItem("token",res.access_token);
          window.localStorage.setItem("mobile",res.mobile); 
          window.localStorage.setItem("otp",res.otp); 

          this.hideMe = true;
        }
      }, (err) => {
        console.log(err);
      });
  }




  onFormSubmit1(form: NgForm) {
  console.log("form",form)
    this.authService.login1(form)
      .subscribe(res => {     
      // alert("res "+ JSON.stringify(res));
          if (!res.Error) {
          window.localStorage.removeItem("token");
          
          window.localStorage.setItem("token",res.access_token);
          window.localStorage.setItem("token_type",res.token_type);
          console.log("id",res);
          window.localStorage.removeItem("name");
          window.localStorage.setItem("name",res.user.name);
          window.localStorage.removeItem("father_name");
          window.localStorage.setItem("father_name",res.user.father_name);
          window.localStorage.removeItem("father_mobile_no");
          window.localStorage.setItem("father_mobile_no",res.user.father_mobile_no);
          window.localStorage.removeItem("id");
          window.localStorage.setItem("id",res.id);
          this.authService.isLoggedIn=true;
          window.localStorage.removeItem("member_type");
          window.localStorage.setItem("member_type",res.user.member_type);
          window.localStorage.removeItem("category_name");
          window.localStorage.setItem("category_name",res.user.category_name);
          window.localStorage.setItem("category_status",res.user.category_status);

          if(res.user.category_status>0){
          this.router.navigate(['exam2']);
          }

          if(res.user.category_status==0){
          this.router.navigate(['exam']);
          }


          }
        else
        {alert(res.message);}


      }, (err) => {
        console.log(err);
        //alert("msg",res['message']);
      });
  }

  register() {
    this.router.navigate(['register']);
  }

  async presentToast(msg) {
    const toast = await this.toastController.create({
      message: msg,
      duration: 20000,
      position: 'top'
    });
    toast.present();
  }

  sendto(page) {
    console.log(page);
        this.router.navigate([page]);
    
  }

}
