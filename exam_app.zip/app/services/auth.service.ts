import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { Operator } from '../operator';
import { Transaction } from '../transaction';

import { Deposit } from '../model/deposit';
import { Bank } from '../model/bank';
import { Center } from '../model/center';

import { Test } from '../model/test';
import { Question } from '../model/questions';
import { Answer } from '../model/answer';
import { Result} from '../model/result';
import { testsummery } from '../model/testsummery';
import { Category } from '../model/category';
import { Questionreview } from '../model/questionreview';


import { Platform } from '@ionic/angular';
import { BehaviorSubject } from 'rxjs';
 import { Storage } from '@ionic/storage';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  apiUrl = 'https://onlineexam.saksh.website/vapi/centerstudent/';
  isLoggedIn = false;
  redirectUrl: string; 
  token:any={};

  
 username: string; 

 password : string; 
 

constructor(private http: HttpClient,public storage: Storage ){
  if(window.localStorage.getItem("token")){
    let value= storage.get("token")
    this.token["access_token"]=window.localStorage.getItem("token")
    this.token["token_type"]=window.localStorage.getItem("token_type")
    console.log(this.token)
  }
  else{
    let value= storage.get("token")
    console.log(value)

  }
 }
 
 
  
  getchat(type:any): Observable<any> {
  const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });



    return this.http.get<Question[]>(this.apiUrl + 'chat.php?q='+type, { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getQuestions')),
        catchError(this.handleError('getQuestions', []))

        );
  }


  getchat1(type:any,type1:any,files:any,file_name:any,value_extension:any): Observable<any> {

    
  const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });



    return this.http.get<Question[]>(this.apiUrl + 'chat.php?q='+type+'&files='+files+'&msg='+type1+'&file_name='+file_name+'&ext_value='+value_extension, { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getQuestions')),
        catchError(this.handleError('getQuestions', []))

        );
  }
 
  login(data: any): Observable<any> {
	 
	
	  
    return this.http.post<any>(this.apiUrl + 'sendsms.php', data)
      .pipe(
	 
             tap(token => {
        this.storage.set('token', token)
       

        .then(
          () => {
            console.log('Token Stored login ',token);
            // alert(token.message);
          },
          error => console.error('Error storing item', error)
        );
        this.token = token;
        console.log("token login",this.token);
        console.log("this.token login  access_token",this.token["access_token"])
 
        this.isLoggedIn = true;
        return token;
      }),
    );
  }
  

  login1(data: any): Observable<any> {
   
  let mobile = window.localStorage.getItem("mobile");  
  // window.localStorage.removeItem("token");
    
    console.log("data",data,"mobile->",mobile)
    return this.http.post<any>(this.apiUrl + 'login.php?mobile='+mobile, data)
      .pipe(
   
             tap(token => {

        this.storage.set('token', token)
        

        .then(
          () => {
            console.log('Token Stored login1',token);
          },
          error => console.error('Error storing item', error)
        );
        // this.token = token;
        this.token = token;
        console.log("token login1",this.token);
        console.log("this.token login1 access_token",this.token["access_token"])
 
  
        this.isLoggedIn = true;
        return token;
      }),
    );
  }


   mm(data: any): Observable<any> {
  
  
    
    return this.http.post<any>(this.apiUrl + 'attempt.php', data)
      .pipe(
   
        tap(_ => this.isLoggedIn = true   ),
        catchError(this.handleError('mm', []))
      );
  }



getcategory(): Observable<any> {

  const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });



    return this.http.get<Question[]>(this.apiUrl + 'category.php', { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getQuestions')),
        catchError(this.handleError('getQuestions', []))

        );
  }

   attempttest(): Observable<any> {

  const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });



    return this.http.get<Question[]>(this.apiUrl + 'attempttest.php', { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getQuestions')),
        catchError(this.handleError('getQuestions', []))

        );
  }




  subject(data: any): Observable<any> {

   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });
    
    
    
    return this.http.post<any>(this.apiUrl + 'subject.php', data, { headers: headers })
      .pipe(
        tap(_ => this.log('subject')),
        catchError(this.handleError('subject', []))
      );
  } 





   getuserById(): Observable<any> {

  const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });



    return this.http.get<Question[]>(this.apiUrl + 'getuserById.php', { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getQuestions')),
        catchError(this.handleError('getQuestions', []))

        );
  }


     updateProfile(data:any): Observable<any> {
      const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });
    
   return this.http.post<any[]>(this.apiUrl + 'updateProfile.php', data , { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getQuestions')),
        catchError(this.handleError('getQuestions', []))

        );
  }
   
  mm1(data: any): Observable<any> {
  //alert(this.token["token_type"]+" "+this.token["access_token"]);
   
   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });
    
    return this.http.post<any>(this.apiUrl + 'attempt.php', data, { headers: headers })
      .pipe(
   
       tap(_ => this.log('mm')),
        catchError(this.handleError('mm', []))
      );
  }
    
   answer(data: any): Observable<any> {


//alert(this.token["token_type"]+" "+this.token["access_token"]);



	   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });
	  
	  
    return this.http.post<any>(this.apiUrl + 'answer.php', data, { headers: headers })
      .pipe(
        tap(_ => this.log('answer')),
        catchError(this.handleError('answer', []))
      );
  } 
  /*
 attempt(data: any): Observable<any> {


//alert(this.token["token_type"]+" "+this.token["access_token"]);

	  
	   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });
	  
    return this.http.post<any>(this.apiUrl + 'attempt1.php', data, { headers: headers })
      .pipe(
        tap(_ => this.log(' attempt')),
        catchError(this.handleError(' attempt', []))
      );
  } 
/*
 getQuestions(  type): Observable<Question[]> {

  const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });

    return this.http.get<Question[]>(this.apiUrl + 'questions.php?category='+type, { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getQuestions')),
        catchError(this.handleError('getQuestions', []))
      );
  }*/
  
  getAnswer(type,type1): Observable<Answer> {

  const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });

    return this.http.get<any>(this.apiUrl + 'answersheet.php?test_id='+type+'&attempt_id='+type1, { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getAnswer')),
        catchError(this.handleError('getAnswer', []))
      );
  }


  getAnswers(  type,type1): Observable<Answer[]> {

  const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });

    return this.http.get<any>(this.apiUrl + 'answersheet.php?test_id='+type+'&attempt_id='+type1, { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getAnswer')),
        catchError(this.handleError('getAnswer', []))
      );
  }



profile(data: any): Observable<any> {

const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });

  return this.http.post<any>(this.apiUrl +'profile1.php',data)
      .pipe(
        tap(_ => this.log('data insert')),
        catchError(this.handleError('data insert', []))
      );
  } 
    getTests(   ): Observable<Test[]> {


    const headers = new HttpHeaders({
      'Authorization': this.token["access_token"]
    });

    console.log("hre")
// return
    return this.http.get<Test[]>(this.apiUrl + 'tests.php', { headers: headers })
      .pipe(
        tap(_ => this.log('fetched Test')),
        catchError(this.handleError('Test', []))
    
      );
  
  }
  
   getResult(   ): Observable<Result[]> {

 

    const headers = new HttpHeaders({
      'Authorization': this.token["access_token"]
    });

    return this.http.get<Result[]>(this.apiUrl + 'attempt_test.php', { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getResult')),
        catchError(this.handleError('getResult', []))
		
      );
	
  }
  
   testsummery(  type,type1): Observable<testsummery []> {

    const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });

    return this.http.get<testsummery []>(this.apiUrl + 'testsummery.php?test_id='+type+'&attempt_id='+type1,{ headers: headers })
      .pipe(
        tap(_ => this.log('fetched  testsummery')),
        catchError(this.handleError(' testsummery', []))
      );
  }
  
  
  register(data: any): Observable<any> {

   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });
	  
	  
	  
    return this.http.post<any>(this.apiUrl + 'register.php', data, { headers: headers })
      .pipe(
        tap(_ => this.log('register')),
        catchError(this.handleError('register', []))
      );
  } 



  
  
   

 
 
 
  
    getTest(data: any): Observable<any> {
	  
//alert(this.token["token_type"]+" "+this.token["access_token"]);

	   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });
	  
    return this.http.post<any>(this.apiUrl + 'test.php?test_id='+data, data, { headers: headers })
      .pipe(
        tap(_ => this.log('register')),
        catchError(this.handleError('register', []))
      );
  } 
  
  
  
  
  getTests2( ): Observable<Test[]> {
alert("ss");
   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });

    return this.http.get<Test[]>(this.apiUrl + 'tests.php?23423=23423', { headers: headers })
      .pipe(
        tap(_ => this.log('fetched Operator')),
        catchError(this.handleError('getOperator', []))
      );
  }

getQuestions( type): Observable<Question[]> {

//alert(this.token["token_type"]+" "+this.token["access_token"]);

 const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });

    return this.http.get<Question[]>(this.apiUrl + 'questions.php?test_id='+type , { headers: headers })
      .pipe(
        tap(_ => this.log('fetched Operator')),
        catchError(this.handleError('getQuestions', []))
      );
  }
  
  getQuestionsreview( type,type1): Observable<Questionreview[]> {

   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });
    return this.http.get<Questionreview[]>(this.apiUrl + 'attemptreview.php?test_id='+type+'&attempt_id='+type1, { headers: headers })
      .pipe(
        tap(_ => this.log('fetched Operator')),
        catchError(this.handleError('getQuestionsreview', []))
		
      );

  }
  

getCategory(  type): Observable<Category[]> {

//alert("getCategory")
//alert(this.token["access_token"]);

 const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });

    return this.http.get<Category[]>(this.apiUrl + 'category.php?category='+type, { headers: headers })
      .pipe(
        tap(_ => this.log('fetched getCategory')),
        catchError(this.handleError('getCategory', []))
      );
  }












  
  
  
  
sendDepositRequest(data: any): Observable<any> {
	 
	   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });

    return this.http.post<any>(this.apiUrl + 'processRecharge.php', data, { headers: headers })
      .pipe(
        tap(_ => this.log('processRecharge')),
        catchError(this.handleError('login', []))
      );
  }
  
  
  getOperators(  type): Observable<Operator[]> {

   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });


    return this.http.get<Operator[]>(this.apiUrl + 'GetOperator.php?category='+type, { headers: headers })
      .pipe(
        tap(_ => this.log('fetched Operator')),
        catchError(this.handleError('getOperator', []))
      );
  }
  
  
  
  
  getBank_accounts(auth): Observable<Bank[]> {

 
    
   
	return this.http.get<Bank[]>(this.apiUrl + 'BankDetail.php?cs=self&username='+auth.username+'&password='+auth.password+'&pin='+auth.pin )
      .pipe(
        tap(_ => this.log('fetched Banks')),
        catchError(this.handleError('getOperator', []))
      );
  }
  
  /*
   getTransactions( auth ): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(this.apiUrl + 'Credit_Debit_History.php?username='+auth.username+'&password='+auth.password+'&pin='+auth.pin )
      .pipe(
        tap(_ => this.log('fetched Banks')),
        catchError(this.handleError('getOperator', []))
      );
  }
  
  getDeposits( auth ): Observable<Deposit[]> {
    return this.http.get<Deposit[]>(this.apiUrl + 'Deposits.php?username='+auth.username+'&password='+auth.password+'&pin='+auth.pin+'&cs=self' )
      .pipe(
        tap(_ => this.log('fetched Banks')),
        catchError(this.handleError('getOperator', []))
      );
  }
  
    
  getRechargeTransactions( auth ): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(this.apiUrl + 'RechargeHistory.php?username='+auth.username+'&password='+auth.password+'&pin='+auth.pin  )
      .pipe(
        tap(_ => this.log('fetched Banks')),
        catchError(this.handleError('getOperator', []))
      );
  }
  
  */
  
   logout(): Observable<any> {
   const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["access_token"]
    });
    return this.http.get<any>(this.apiUrl + 'logout.php', { headers: headers })
      .pipe(
        tap(_ => this.isLoggedIn = false),
        catchError(this.handleError('logout', []))
      );
  }
  
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); // log to console instead
      this.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
 
  private log(message: string) {
    console.log(message);
  }
    
  
  
  
  public set(settingName,value){
    return this.storage.set(settingName ,value);
  }
  public async get(settingName){
    return await this.storage.get(settingName);
  }
  public async remove(settingName){
    return await this.storage.remove(settingName);
  }
  public clear() {
    this.storage.clear().then(() => {
      console.log('all keys cleared');
    });
  }
  
  
}