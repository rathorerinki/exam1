import { Component, OnInit } from '@angular/core';

import { ActionSheetController } from '@ionic/angular';
import { AuthService } from '../services/auth.service';
import { Result } from '../model/result';
import { Storage } from '@ionic/storage';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-result',
  templateUrl: './result.page.html',
  styleUrls: ['./result.page.scss'],
})
export class ResultPage implements OnInit {
result : Result[];
  constructor(public actionSheetController: ActionSheetController, private  authService:  AuthService,
  private  router:  Router,public storage: Storage,private route: ActivatedRoute) { }
   
  async openMenu(test_id,test_name,attempt_id) {
    const actionSheet = await this.actionSheetController.create({
      header: '',
	  mode:'ios',
      buttons: [{
        text: 'Reattempt',
        
        handler: () => {
			
        
		 this.router.navigate(['instructions'],  { queryParams: { special: test_id} });
		 
        }
      }, {
        text: 'Review',
        icon: '',
        handler: () => {
           this.router.navigate(['questionreview'],  { queryParams: { special: test_id, special1: test_name,special2: attempt_id} });
        }
      }, {
        text: 'Cancel',
        icon: 'close',
        role: 'cancel',
        handler: () => {
          console.log('Cancel clicked');
        }
      }]
    });
    await actionSheet.present();
  }


  ngOnInit() {
	  
	  	  
  

	  this.authService.getResult( )
	 
      .subscribe(result => {
        console.log("result",this.result);
         this.result = result;
      });
	   
	 

}
	  
	 sendtoTest(test_id) {
		 //alert(test_id,t_name);
	  this.router.navigate(['instructions'],  { queryParams: { special: test_id} });
	  //alert(test_id,t_name);
     //this.router.navigate(['showexam'],  { queryParams: { special: test_id, special1:t_name } });
	
	  }   
  
  sendtoTestwithanswer(test_id,test_name,attempt_id) {
	  this.router.navigate(['questionreview'],  { queryParams: { special: test_id, special1: test_name,special2: attempt_id} });



 


 }
  
  
}
