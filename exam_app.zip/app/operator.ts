export class Operator {
  
    code: string;
    name: string; 
}