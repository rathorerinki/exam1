import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

import { Answer } from '../model/answer';
import { Marks } from '../model/marks';


@Component({
  selector: 'app-marks',
  templateUrl: './marks.page.html',
  styleUrls: ['./marks.page.scss'],
})
export class MarksPage implements OnInit {

answer : Answer[];
marks : Marks[];
mark;
correct_answer;
incorrect_answer;
total_question;
total_marks;
percentage:number;
percentage1:number;

  constructor(private  authService:  AuthService,
  private  router:  Router) { }

  ngOnInit() {
	  
	  console.log("loading answer  ngOnInit  42 ");


	 // alert("all");
    let test_id = window.localStorage.getItem("test_id");
    let res = window.localStorage.getItem("res"); 
    let total_marks = window.localStorage.getItem("total_marks"); 


      this.authService.getAnswer(+test_id,res)
      .subscribe(answer => {


//{"correct_answer":3,"incorrect_answer":0,"mark":12,"total_question":4}



        console.log(answer);


         this.mark= answer.mark;
         this.correct_answer=answer.correct_answer;
         this.incorrect_answer=answer.incorrect_answer;
         this.total_question=answer.total_question;
         this.total_marks=answer.total_marks;
         this.percentage=(this.mark*100)/this.total_marks;
        // this.percentage1=parseInt(this.percentage);
         //alert(this.percentage1);

		 console.log("loading answer ngOnInit  42 ");


      });
  }

sendto1(){
let res = window.localStorage.getItem("res");
let test_name = window.localStorage.getItem("test_name");
let test_id = window.localStorage.getItem("test_id");
  this.router.navigate(['questionreview'],  { queryParams: { special: test_id, special1: test_name,special2: res} });
}



sendto() {

   let test_id = window.localStorage.getItem("test_id");
this.router.navigate(['instructions'],  { queryParams: { special: test_id} });
   
    
  }




}
