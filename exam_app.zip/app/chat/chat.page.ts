import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthService } from '../services/auth.service';
import { Test } from '../model/test';

 import { Storage } from '@ionic/storage';
import { Answer } from '../model/answer';
import { Question } from '../model/questions';

import { Center } from '../model/center';
import { LoadingController,Platform } from '@ionic/angular';
//  import { Subscription } from '@ionic/rxjs';
import { Subscription } from 'rxjs/Subscription';
import * as $ from "jquery";

import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import{FilePath} from '@ionic-native/file-path/ngx';
import{FileChooser} from '@ionic-native/file-chooser/ngx';
import 'rxjs/add/operator/toPromise';
import { FileOpener } from '@ionic-native/file-opener/ngx';



@Component({
  selector: 'app-chat',
  templateUrl: './chat.page.html',
  styleUrls: ['./chat.page.scss'],
})
export class ChatPage implements OnInit {
//  file: File;
  
	center: Center[];
	questions:Question[];
	
  chat: Test[];
  tests1:any;
  data: any;
  now:any;
  newMsg='';
  msg:any;
  image:any;
  imageFileName:boolean=false;
  currentUser:any;
  paramsSubscription : Subscription;
  processing: boolean;
  uploadImage: boolean=false;
  file_data:any;
  image_file: any;
  files_name:any;

  image_path:any;
  uploadtext:any;
  downloadtext:any;
  // fileTransferObject:FileTransferObject;
  transfer: FileTransferObject=this.fileTransfer.create();
  
  file_link: any;
  extension: string;
  hide_condition:any=[];
  constructor(private authService: AuthService,public storage: Storage,
  private route: ActivatedRoute, private router: Router,public loadingController: LoadingController,private fileTransfer:FileTransfer,private file:File,private filePath:FilePath,private fileChoosesr:FileChooser, public platform: Platform,private fileOpener: FileOpener) {
    this.uploadtext='';
    this.downloadtext='';
   }

  ngOnInit() {
  let id=window.localStorage.getItem("id");
  this.currentUser=id;
  this.authService.getchat("chats")
      .subscribe(chat => {
        console.log("test",chat);
         this.chat = chat;
         for(let i=0;i<chat.length;i++){
          this.show_icon(chat[i].filename,i);
         }

      });

      
  }
 
  
  uploadfile(){
    this.fileChoosesr.open()
    .then((uri) => {

              this.filePath.resolveNativePath(uri)
              .then((filePath) =>{   
                var x = Math.floor((Math.random() * 9999) + 1000);            
                    // alert(filePath)
                    let fileExtn=filePath.split('.').reverse()[0];
                    this.extension=fileExtn;
                    let fileMIMEType=this.getMIMEtype(fileExtn);
                    this.transfer=this.fileTransfer.create();
                    let options:FileUploadOptions={
                        fileKey:'videofile',
                        fileName:"file"+x+"."+fileExtn,
                        chunkedMode:false,
                        headers:{},
                        mimeType:fileMIMEType
                    }

                    this.uploadtext='Uploading....';
                    this.uploadImage=true;

                    this.transfer.upload(filePath,'https://onlineexam.saksh.website/vapi/centerstudent/file_upload.php',options).then((data)=>{
                          alert("File uploaded");
                          console.log(data)
                          this.uploadtext='';

                          this.file_link='https://onlineexam.saksh.website/vapi/centerstudent/uploads/'+"file"+x+"."+fileExtn;
                          this.files_name="file"+x+"."+fileExtn;
                          this.authService.getchat1('createchat',this.msg,this.file_link,this.files_name,this.extension)
                          .subscribe(chat => {
                            console.log("test",chat);
                            this.authService.getchat("chats")
                            .subscribe(chat => {
                                console.log("test",chat);
                                this.chat = chat;

                            });

                          });
                    },err=>{
                          console.log("err",err);
                          alert("File failed");
                    })

              })
              .catch(err => console.log(JSON.stringify(err)));
      
      console.log(uri)
    
    })
    .catch(e => console.log(JSON.stringify(e)));

    
  }

  cancel(){
    this.transfer.abort();
    this.uploadtext='';
    alert("Canceling....");
  }

  sendMessage(){
    this.msg=this.newMsg;
    // return false;
    this.file_link='';
    this.files_name='';
    this.extension='';
    this.authService.getchat1('createchat',this.msg,this.file_link,this.files_name,this.extension)
        .subscribe(chat => {
          console.log("test",chat);
          
    this.authService.getchat("chats")
        .subscribe(chat => {
          console.log("test",chat);
          this.chat = chat;

    });

    });


    this.newMsg='';

  }

  download(file, name) {
  
    if (this.platform.is('cordova')) {
      this.file.checkDir(this.file.externalRootDirectory, 'downloads')
      .then(

        // Directory exists, check for file with the same name
        _ => this.file.checkFile(this.file.externalRootDirectory, 'downloads/' + name)
        .then(_ => {
              this.find_file(name);
      })


        // File does not exist yet, we can save normally
        .catch(err =>
          this.transfer.download(file, this.file.externalRootDirectory + '/downloads/' + name).then((entry) => {
                    this.uploadtext='';
                    this.find_file(name);
            })
            .catch((err) =>{
              alert('Error saving file: ' + err.message);
            })
        ))
      .catch(
        // Directory does not exists, create a new one
        err => this.file.createDir(this.file.externalRootDirectory, 'downloads', false)
        .then(response => {
              alert('New folder created:  ' + response.fullPath);
              this.transfer.download(file, this.file.externalRootDirectory + '/downloads/' + name).then((entry) => {
                alert('File saved in : ' + entry.nativeURL);
                    this.find_file(name);
              })
              .catch((err) =>{
              this.uploadtext='';
                alert('Error saving file:  ' + err.message);
              });
      
        }).catch(err => {
          this.uploadtext='';

          alert('It was not possible to create the dir "downloads". Err: ' + err.message);
        })			
      );			 
  
    } else {
      // If downloaded by Web Browser
      let link = document.createElement("a");
      link.download = name;
      link.href = file;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      link = null;
    }
  }
  

find_file(name){
    let fileExtn=name.split('.').reverse()[0];
    let fileMIMEType=this.getMIMEtype(fileExtn);
    this.fileOpener.open(this.file.externalRootDirectory+'downloads/'+name,fileMIMEType)
    .then(() => console.log('File is opened'))
    .catch(e => console.log('Error openening file', e));
}

show_icon(name,i){
  if (this.platform.is('cordova')) {
    // this.uploadtext='Downloading....'
    this.file.checkDir(this.file.externalRootDirectory, 'downloads')
    .then(

      // Directory exists, check for file with the same name
      _ => this.file.checkFile(this.file.externalRootDirectory, 'downloads/' + name)
      .then(_ => {
            this.hide_condition[i]="true"
            document.getElementById( 'hide_'+i).style.display = 'none';

            this.uploadtext='';
            this.find_file(name);
 
    })
    ) .catch(err =>
      {
        document.getElementById( 'hide_'+i).style.display = 'block'; 

      }      
    )
  }
  
}

getMIMEtype(extn){
  let ext=extn.toLowerCase();
  let MIMETypes={
    'txt' :'text/plain',
    'docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'doc' : 'application/msword',
    'pdf' : 'application/pdf',
    'jpg' : 'image/jpeg',
    'bmp' : 'image/bmp',
    'png' : 'image/png',
    'xls' : 'application/vnd.ms-excel',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'rtf' : 'application/rtf',
    'ppt' : 'application/vnd.ms-powerpoint',
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'mpeg' : 'video/mpeg',
    'mp4' : 'video/mp4',

  }
  return MIMETypes[ext];
}


  
}
