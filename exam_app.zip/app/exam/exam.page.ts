import { Component, OnInit } from '@angular/core';
 
import { AuthService } from '../services/auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController, AlertController } from '@ionic/angular';

import { FormBuilder, FormGroup,NgForm, FormArray, FormControl, Validators } from '@angular/forms';
import { Test } from '../model/test';

import { ValueTransformer } from '@angular/compiler/src/util';
@Component({
  selector: 'app-exam',
  templateUrl: './exam.page.html',
  styleUrls: ['./exam.page.scss'],
})
export class ExamPage implements OnInit {


tests: Test[];
 hideMe= true;
Data: Array<any> = [
  { name: 'Pear', value: 'pear' },
  { name: 'Plum', value: 'plum' },
  { name: 'Kiwi', value: 'kiwi' },
  { name: 'Apple', value: 'apple' },
  { name: 'Lime', value: 'lime' }
];
  constructor(private formBuilder: FormBuilder,private authService: AuthService,
  private route: ActivatedRoute, private router: Router, public toastController: ToastController,
    public alertController: AlertController) { }


   addForm: FormGroup;
  ngOnInit() {




    this.authService.getcategory()
      .subscribe(tests => {
        console.log("test",tests);
         this.tests = tests;



      });


  this.addForm = this.formBuilder.group({
     
checkArray: this.formBuilder.array([])      
    });

  }

    onSubmit(form: NgForm) {
    this.authService.subject(form)
      .subscribe( data => {
        alert(data['Message'])
            
      });
  }



 onFormSubmit(form: NgForm) { 
  
    this.authService.subject(form)
      .subscribe(_ => {
        this.presentAlert('Subject added Successfully', 'Subject added Successfully');
         
         this.router.navigate(['exam2']);
      }, (err) => {
        console.log(err);
      });
  }

  async presentToast(msg) {
    const toast = await this.toastController.create({
      message: msg,
      duration: 2000,
      position: 'top'
    });
    toast.present();
  }

  async presentAlert(header, message) {
    const alert = await this.alertController.create({
      header: header,
      message: message,
      buttons: [{
          text: 'OK',
          handler: () => {
            //this.router.navigate(['login']);
          }
        }]
    });

    await alert.present();
  }

  
onCheckboxChange(e) {
 window.localStorage.removeItem("category_name");
    window.localStorage.setItem("category_name",e.target.value);
console.log("value",e.target.value);
 this.hideMe = false;
 // alert("s");
  const checkArray: FormArray = this.addForm.get('checkArray') as FormArray;

  if (e.target.checked) {
    checkArray.push(new FormControl(e.target.value));
  } else {
    let i: number = 0;
    checkArray.controls.forEach((item: FormControl) => {
    
      if (item.value == e.target.value) {
        checkArray.removeAt(i);
        return;
      }
      i++;
    });
  }
  
  console.log(checkArray);
}
}


