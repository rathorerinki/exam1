import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

import { Center } from '../model/center';

import { AuthService } from '../services/auth.service';

import { Storage } from '@ionic/storage';
import { Category } from '../model/category';
  
 
//  import { Subscription } from '@ionic/rxjs';
import { Subscription } from 'rxjs/Subscription';
import { LoadingController } from '@ionic/angular';
 

@Component({
  selector: 'app-category',
  templateUrl: './category.page.html',
  styleUrls: ['./category.page.scss'],
})
export class CategoryPage implements OnInit {
	
	category: Category[];
	
 paramsSubscription : Subscription;
	
 constructor(private authService: AuthService, private route: ActivatedRoute,
    private router: Router ,public storage: Storage ,public loadingController: LoadingController) {
		
   	}
	

  ngOnInit() { 




   console.log("loading category ngOnInit  42 ");

   
     this.paramsSubscription = this.authService.getCategory( "all" )
      .subscribe(category => {
        console.log(category);
         this.category = category;
		 
		 console.log("loading centers ngOnInit  42 ");
     //this.storage.set("cid",category.id);


      });
     
  }
  
  
    sendto(page) {
    console.log(page);
        this.router.navigate([page]);
    
  }

  async presentLoadingWithOptions(page) {
    const loading = await this.loadingController.create({
      spinner:"bubbles",
      duration: 500,
      message: 'Please wait...',
      translucent: true,
      cssClass: 'custom-class custom-loading'
    });

    this.router.navigate(['center'],  { queryParams: { special: page } });
    console.log("kfdj",page);
    window.localStorage.removeItem("special");
    window.localStorage.setItem("special",page);
    return await loading.present();

    
  }

    sendtoTest(page) {


 

  
		
		//this.storage.get("id").then(r => {
     // if (r) {
		  
    this.router.navigate(['center'],  { queryParams: { special: page } });
    console.log("kfdj",page);
    window.localStorage.removeItem("special");
    window.localStorage.setItem("special",page);
	//alert("kfdj",cid);
	 // }
//  })

    
    
		}
   ngOnDestroy() {
	    
      console.log("loading centers ngOnDestroy  73 ");
	 this.paramsSubscription.unsubscribe();
	 
      console.log("loading centers ngOnDestroy  76 ");
   }
  
  
}
