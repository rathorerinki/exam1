import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { Storage } from '@ionic/storage';
import { ModalController } from '@ionic/angular';
import { NavParams } from '@ionic/angular'; 
import { IonSlides } from '@ionic/angular';

import { ViewChild } from '@angular/core'


import { SummeryPage } from '../summery/summery.page';
 
import { Question } from '../model/questions';



@Component({
  selector: 'app-showexam',
  templateUrl: './showexam.page.html',
  styleUrls: ['./showexam.page.scss'],
})
export class ShowexamPage implements OnInit {
	questions : Question[];

 timeInSeconds:any;
 time:any;
 //time3:bigint;

  runTimer:any;
  hasStarted:any;
  hasFinished:any;
  remainingTime:any;
  displayTime:any;
  
//@ViewChild('slides',{static:true}) slides: IonSlides;


@ViewChild('slides') slides: IonSlides;

  data;
  data1;
  data2;
  data3;
  data4;
  data5;
  qid1;
  hideMe= false;
  hideMe1= false;

  slideOpt = {
    initialSlide: 0,
   // speed: 4,
   
  };
  
  constructor( 
    private router: Router,
    private authService: AuthService ,
	public storage: Storage,
	public modalController: ModalController,
	private route: ActivatedRoute 
	) { }



  ngOnInit() {

 
	  
		this.route.queryParams.subscribe(params => {
    this.data =  params.special ;
	  this.data1 =  params.special1 ;
    this.data2 =  params.special2 ;
    this.data3 =  params.special3 ;
    this.data4 =  params.special4 ;
    this.data5 =  params.special5 ;
     window.localStorage.removeItem("time_hour");
    window.localStorage.setItem("time_hour", params.special4);
  window.localStorage.removeItem("time_minute");
    window.localStorage.setItem("time_minute", params.special5);
  
	  
	  //alert(params.special5);
     this.initTimer();
  this.startTimer();
	 // alert(question_id);
   window.localStorage.removeItem("test_name");
    window.localStorage.setItem("test_name",this.data1);

	   console.log("loading questions  ngOnInit  42 ");
        this.authService.getQuestions(params.special)
      .subscribe(questions => {
        console.log(questions);
         this.questions = questions; 
		 console.log("loading questions ngOnInit  42 ");
		 
      });
	  
	console.log("par",params);
	 // alert(this.data1);
		
      
	  
  });
	 

  }
  
  

    editquestion( ) {
    this.router.navigate(['edit-question']);
    
  }
  
  async openModal( ) {

window.localStorage.removeItem("test_id");
    window.localStorage.setItem("test_id",this.data);
//alert( "testid"+this.data );
 
   const modal = await this.modalController.create({
      component:SummeryPage,
    componentProps: {
      'test_id': this.data
    }
    });

   modal.onDidDismiss()
     .then((data) => {
       const user = data['data']; 
       console.log(user);
       

 let editQuestionId = window.localStorage.getItem("editQuestionId");
    //alert("insideddwewewewewewewewewewewewewewewewewe"+editQuestionId);

this.qid1=parseInt(editQuestionId);
    
 this.slides.slideTo(this.qid1-1);
 //alert(editQuestionId);
console.log("qid",this.qid1);

   });
    return await modal.present();
 
}
  
  
  sendto(page) {
	 
    console.log(page);
        this.router.navigate([page] );
    
  }
checkionSlidePrevStart()
{
//alert("called prev");
  this.hideMe1 = true;
  
}

checkionSlideReachEnd()
{
  //alert("called");
  this.hideMe = true;
}

sendtoslide( editQuestionId) {

      this.slides.slideTo(editQuestionId);
      
}

sendtoP( ) {
      this.slides.slidePrev();

      console.log(this.slides.ionSlideReachEnd );
}
sendtoN( ) {
      this.slides.slideNext();
 console.log(this.slides.ionSlideReachEnd );
	  
}
  
  answer(q,a) {

  
	 // alert("Your answer "+a+" for the questions "+q );


	 
	 
	 // this.storage.get("id").then(r => {
    //  if (r) {
    let id = window.localStorage.getItem("editQuestionId");
           
   let attempt_id = window.localStorage.getItem("res");    
	var data = JSON.stringify({"q":q, "a":a,"attempt_id":attempt_id});


//alert("Your answer "+a+" for the questions "+q );




 this.authService.answer(data).subscribe((res) => {
  console.log(res);

   // this.router.navigate([page]);
    
  });
     // }


  //  })
	  
	
	 
	  
	  
	
}



initTimer() {
     // Pomodoro is usually for 25 minutes
    if (!this.timeInSeconds) {
      let time1=  window.localStorage.getItem("time_hour");
      let time2=  window.localStorage.getItem("time_minute");

      var time3=Math.floor(parseInt(time1)*60*60);
      var time4=Math.floor(parseInt(time2)*60);
      var time5=Math.floor(time3+time4);
   //   alert(time5);
   
    
      this.timeInSeconds = time5; 
          //  this.timeInSeconds = 60; 
    }
  
    this.time = this.timeInSeconds;
    this.runTimer = false;
    this.hasStarted = false;
    this.hasFinished = false;
    this.remainingTime = this.timeInSeconds;
    
    this.displayTime = this.getSecondsAsDigitalClock(this.remainingTime);
  }
  
  startTimer() {
     this.runTimer = true;
    this.hasStarted = true;
    this.timerTick();
  }
  
  pauseTimer() {
    this.runTimer = false;
   
  }
  
  resumeTimer() {
    this.startTimer();

  }
  
  timerTick() {
    setTimeout(() => {
  
      if (!this.runTimer) { return; }
      this.remainingTime--;
      this.displayTime = this.getSecondsAsDigitalClock(this.remainingTime);
      if (this.remainingTime > 0) {
        this.timerTick();
      }
      else {
        this.hasFinished = true;
        //alert("time over");
         this.router.navigate(['marks']);

        
        
      }
    }, 1000);
  }
  
  getSecondsAsDigitalClock(inputSeconds: number) {
    var sec_num = parseInt(inputSeconds.toString(), 10); // don't forget the second param
    var hours = Math.floor(sec_num / 3600);
    var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
    var seconds = sec_num - (hours * 3600) - (minutes * 60);
    var hoursString = '';
    var minutesString = '';
    var secondsString = '';
    hoursString = (hours < 10) ? "0" + hours : hours.toString();
    minutesString = (minutes < 10) ? "0" + minutes : minutes.toString();
    secondsString = (seconds < 10) ? "0" + seconds : seconds.toString();
    return hoursString + ':' + minutesString + ':' + secondsString;
  }
}
