import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowexamPage } from './showexam.page';

describe('ShowexamPage', () => {
  let component: ShowexamPage;
  let fixture: ComponentFixture<ShowexamPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowexamPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowexamPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
