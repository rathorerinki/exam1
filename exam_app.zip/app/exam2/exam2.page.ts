

import { Component, OnInit ,OnDestroy} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthService } from '../services/auth.service';
import { Test } from '../model/test';

 import { Storage } from '@ionic/storage';
import { Answer } from '../model/answer';
import { Question } from '../model/questions';

import { Center } from '../model/center';
import { LoadingController } from '@ionic/angular';


//  import { Subscription } from '@ionic/rxjs';
import { Subscription } from 'rxjs/Subscription';
 
@Component({
	  selector: 'app-exam2',
  templateUrl: './exam2.page.html',
  styleUrls: ['./exam2.page.scss'],
})


export class Exam2Page implements OnInit  {
	 
	
	center: Center[];
	questions:Question[];
	
tests: Test[];
tests1:any;
data: any;
now:any;
 paramsSubscription : Subscription;


  constructor(private authService: AuthService,public storage: Storage,
  private route: ActivatedRoute, private router: Router,public loadingController: LoadingController) 

  {
  
    // alert(this.storage.get("token"))

		
		
  }
  
  
  ngOnInit() {
 
  
   this.getData();
 
	
	    
	}


  reload() { 
    this.getData();
}


getData() { 
 
    this.authService.getTests( )
      .subscribe(tests => {
        console.log("test",tests);
         this.tests = tests;


      });
}


 getQuestions(id): void {
	  // alert("question");
	  console.log("loading question");
    console.log(id);
	  this.authService.getQuestions( id )
      .subscribe(questions => {
        console.log(questions);
         this.questions = questions;
      });
	   
	}
 
   
   

    sendtoAddTest( ) {
    
    console.log( this.data);
   
    this.router.navigate(['addexam'],  { queryParams: { special:this.data } });
	   }



  async presentLoadingWithOptions(test_id,t_name,paid,topen) {
    const loading = await this.loadingController.create({
      spinner:"bubbles",
      duration: 500,
      message: 'Please wait...',
      translucent: true,
      cssClass: 'custom-class custom-loading'
    });



   // alert(paid)

   if(parseInt(paid)==1){


      alert("Please Contact to center")

      }

else
      if(parseInt(topen) > 0){


      alert("Please Contact to center")
     
      }

  else  {

  


   this.router.navigate(['instructions'],  { queryParams: { special: test_id, special1:t_name} });
           
     
 
  }

 
    
 return await loading.present();
    
  }
	    

     
  sendtoTest(test_id,t_name,paid) {
 
/*

   if(parseInt(paid)==0){


      alert("Contact to center")
      }

  if(parseInt(paid)==1){
this.router.navigate(['instructions'],  { queryParams: { special: test_id, special1:t_name} });
  }
	

  */
	  }


 }
 
 
 