import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { Exam2Page } from './exam2.page';

const routes: Routes = [
  {
    path: '',
    component: Exam2Page
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
	 
    RouterModule.forChild(routes)
  ],
  declarations: [Exam2Page]
})
export class Exam2PageModule {}
