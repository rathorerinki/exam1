import { Component, OnInit, Input } from '@angular/core';

import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ModalController } from '@ionic/angular';

import { Answer } from '../model/answer';
import { Question } from '../model/questions';
import { testsummery } from '../model/testsummery';;
import { NavParams } from '@ionic/angular';

@Component({
  selector: 'app-summery',
  templateUrl: './summery.page.html',
  styleUrls: ['./summery.page.scss'],
})
export class SummeryPage implements OnInit {
paramas;
answer : Answer[];
questions:Question[];
testsummery:testsummery[];


   
     @Input() test_id: string;


  constructor(private  authService:  AuthService,navParams: NavParams,
 public viewCtrl: ModalController,
  private  router:  Router) {
    
  }
ngOnInit() {

    let test_id = window.localStorage.getItem("test_id");
    let res = window.localStorage.getItem("res");

    /*  this.authService.getAnswers(+test_id,res )
      .subscribe(answer => {
        console.log(answer);
         this.answer= answer; 
      });*/


      /*  this.authService.getQuestions( "all" )
      .subscribe(questions => {
        console.log(questions);
         this.questions = questions; 
		 console.log("loading questions ngOnInit  42 ");
      });*/


	

//let res = window.localStorage.getItem("res"); 
        this.authService.testsummery(+test_id,res)
        .subscribe(testsummery => {
        console.log(testsummery);
         this.testsummery = testsummery; 
		 console.log("loading testsummery ngOnInit  42 ");

      });
	  
	  
	  
  }
  
  dismiss(question_id) {
  window.localStorage.removeItem("editQuestionId");
  window.localStorage.setItem("editQuestionId",question_id);
	this.viewCtrl.dismiss(question_id);

}
  sendto(page) {
  this.viewCtrl.dismiss();
    console.log(page);
        this.router.navigate([page]);
    
  }

viewquestion(question_id) {
        this.router.navigate(['showexam'],  { queryParams: { special: question_id }});
     
    
  }



}
