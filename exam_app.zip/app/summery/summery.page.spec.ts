import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummeryPage } from './summery.page';

describe('SummeryPage', () => {
  let component: SummeryPage;
  let fixture: ComponentFixture<SummeryPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummeryPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummeryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
