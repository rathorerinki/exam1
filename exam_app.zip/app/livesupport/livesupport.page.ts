import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-livesupport',
  templateUrl: './livesupport.page.html',
  styleUrls: ['./livesupport.page.scss'],
})
export class LivesupportPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
