import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LivesupportPage } from './livesupport.page';

describe('LivesupportPage', () => {
  let component: LivesupportPage;
  let fixture: ComponentFixture<LivesupportPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LivesupportPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LivesupportPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
