import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-application',
  templateUrl: './about-application.page.html',
  styleUrls: ['./about-application.page.scss'],
})
export class AboutApplicationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
