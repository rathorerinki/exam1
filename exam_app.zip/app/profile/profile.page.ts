import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Storage } from '@ionic/storage';
import { AuthService } from '../services/auth.service';




import {FormBuilder, FormGroup,NgForm, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import {Router} from "@angular/router";


@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
 name:any;
  editForm: FormGroup;
 mobile_no:any;
 father_name:any;
father_mobile_no:any;

  constructor(
    private authService: AuthService,private formBuilder: FormBuilder,private router: Router) { }

  ngOnInit() {


 this.editForm = this.formBuilder.group({
      id: [''],                             
      name: [''], mobile_no:[''],father_name: [''] ,father_mobile_no:[''],status:[''], 	center_id:[''],
      created_at:[''],updated_at:[''],marks:[''],member_type:[''],category_status:[''],category_name:['']
     });
     
    this.authService.getuserById()
      .subscribe( data => {
        this.editForm.setValue(data.result);
     

      });

  }



  onSubmit(form: NgForm) {
	 
    this.authService.updateProfile(form)
      .pipe(first())
      .subscribe(
        data => {
        console.log("data",data);
          if(data.status === 200) {
           alert(data.message);
      
          }else {
            alert(data.message);
             
          }
        },
        error => {
          alert(error);
        });
  }





}
