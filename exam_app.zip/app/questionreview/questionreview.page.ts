import { Component, OnInit } from '@angular/core';

import {ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { Storage } from '@ionic/storage';
import { ModalController } from '@ionic/angular';
import { NavParams } from '@ionic/angular'; 


 
import { Question } from '../model/questions';
import { Questionreview } from '../model/questionreview';
import { IonSlides } from '@ionic/angular';

import { ViewChild } from '@angular/core'

@Component({
  selector: 'app-questionreview',
  templateUrl: './questionreview.page.html',
  styleUrls: ['./questionreview.page.scss'],
})


export class QuestionreviewPage implements OnInit {
questionreview : Questionreview[];

 @ViewChild('slides' ) slides: IonSlides;

  data;
  data1;
  slideOpts = {
    initialSlide: 0,
    speed: 4
  };
  
  constructor( 
    private router: Router,
    private authService: AuthService ,
	public storage: Storage,
	public modalController: ModalController,
	private route: ActivatedRoute 
	) { }

  ngOnInit() {
	  
		this.route.queryParams.subscribe(params => {
       this.data =  params.special ;
	  this.data1 =  params.special2 ;
	// alert(params.special2); 
	  
	  
	   console.log("loading questions  ngOnInit  42 ");
        this.authService.getQuestionsreview(params.special,params.special2)
	 
      .subscribe(questionreview => {
        console.log(questionreview);
         this.questionreview = questionreview; 
		 console.log("loading questions ngOnInit  42 ");
		 //alert(params.special2); 
		 
      });
	  
	// console.log("par",params);
	 // alert(this.data1);
		
      
	  
  });
	 

  }
  
  

    editquestion( ) {
    this.router.navigate(['edit-question']);
    
  }
   sendtoslide( cmd) {
      this.slides.slideTo(cmd);
}

sendtoP(  ) {
      this.slides.slidePrev();
}
sendtoN(  ) {
      this.slides.slideNext();
}



 

  
  
  sendto(page) {
	 
    console.log(page);
        this.router.navigate([page] );
    
  }
  
  answer(q,a) {
	  
	  this.storage.get("res").then(r1 => {
      if (r1) {		  
	 
	 
	  this.storage.get("token").then(r => {
      if (r) {
         
	var data = JSON.stringify({"token":r, "q":q, "a":a,"attempt_id":r1});
//alert("Your answer "+a+" for the questions "+q );
//alert(r1);
 this.authService.answer(data).subscribe((res) => {
  console.log(res);

   // this.router.navigate([page]);
    
  });
      }
    })
	  }
	   })
	
	 
	  
	  
	
}
}

