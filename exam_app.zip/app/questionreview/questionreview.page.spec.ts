import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionreviewPage } from './questionreview.page';

describe('QuestionreviewPage', () => {
  let component: QuestionreviewPage;
  let fixture: ComponentFixture<QuestionreviewPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestionreviewPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionreviewPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
