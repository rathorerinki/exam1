import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { QuestionreviewPage } from './questionreview.page';
import { AnswersheetPage } from '../answersheet/answersheet.page';

const routes: Routes = [
  {
    path: '',
    component: QuestionreviewPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [QuestionreviewPage]
  
})
export class QuestionreviewPageModule {}
