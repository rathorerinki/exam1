export class Center {
  
    name: string;
    about: string;   


}