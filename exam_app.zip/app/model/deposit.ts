export class Deposit {
  
    reference_no: string;
    id: string; 
	 username: string;
    transaction_type: string; 
	 status: string;
    cr: string;  


}