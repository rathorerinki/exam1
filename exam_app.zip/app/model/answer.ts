export class Answer {
  
   
     mark:string;
    correct_answer:string;
    incorrect_answer:string;
    total_question:string;
    total_marks:string;


}