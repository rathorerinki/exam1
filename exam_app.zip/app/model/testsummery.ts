export class testsummery {
  
    name: string;
    about: string;   

    center_id: string;   


}