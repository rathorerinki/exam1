export class Category {

 attempt_id: string;
   test_id: string;   

    student_id: string;   



}