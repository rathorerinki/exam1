export class Test {
 id:any; 
name: any; 
question: any;  
duration:any;
marks:any;
created_by:any;
Subject:any;


}