export class Marks {


    account_name: string; 
    mark;
    correct_answer;
    incorrect_answer;
    total_question; 


}