export class Bank {
  
    bank_name: string;
    id: string; 
	 account_no: string;
    ifsc: string; 
	 username: string;
    account_name: string;  


}