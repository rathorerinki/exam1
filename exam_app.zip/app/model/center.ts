export class Center {
  
    name: string;
    about: string;   

    center_id: string;   


}