export class Result {

 attempt_id: string;
   test_id: string;   

    student_id: string;   


}