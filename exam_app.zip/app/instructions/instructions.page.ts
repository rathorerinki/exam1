import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';

import { AuthService } from '../services/auth.service';
import { Test } from '../model/test';

 import { Storage } from '@ionic/storage';
import { Answer } from '../model/answer';
import { Question } from '../model/questions';

import { Center } from '../model/center';


//  import { Subscription } from '@ionic/rxjs';
import { Subscription } from 'rxjs/Subscription';
import { LoadingController } from '@ionic/angular';



@Component({
  selector: 'app-instructions',
  templateUrl: './instructions.page.html',
  styleUrls: ['./instructions.page.scss'],
})
export class InstructionsPage implements OnInit {
	
	test_id;
	name;
	duration_minute;
	duration_hour;
	question;
	description;  
	negativemarks;
	total_marks;
	  hideMe= false;
	  public show:boolean = false;
  public buttonName:any = 'Show';
marks;
created_by;
	center: Center[];
	questions: Question[];
	
test: Test[];
data: any;
 paramsSubscription : Subscription;
  constructor(private authService: AuthService,public storage: Storage,
  private route: ActivatedRoute, private router: Router,public loadingController: LoadingController) {
  
	 	
  }


  ngOnInit() {

 
 
 this.paramsSubscription =	  this.route.queryParams.subscribe(params => {
      
        this.test_id =  params.special ;
		     
	   this.getTest(this.test_id);
	    window.localStorage.setItem('data1', this.test_id);
	   
    });
	
	    
    
	  this.authService.getTest(this.test_id)
      .subscribe(test => {
      
         this.test = test;
		 
		 this.name=test.name;
		 this.duration_hour=test.duration_hour;
		 this.duration_minute=test.duration_minute;
		  this.marks=test.marks;
		 this.question=test.question;
		  this.description=test.description;
		  //this.created_by=test.created_by;
		 this.negativemarks=test.negativemarks;
		this.total_marks= this.question*this.marks;
		 console.log("test",this.test ,this.total_marks);
		// alert(this.name);
		  window.localStorage.removeItem("total_marks");

    window.localStorage.setItem("total_marks",this.total_marks);
      });
	
  }
  
  
	  
 getQuestions(id): void {
	   //alert("question");
	  console.log("loading question");
    console.log(id);
	  this.authService.getQuestions( id )
      .subscribe(questions => {
        console.log(questions);
         this.questions = questions;
      });
	   
	}

 getTest(id): void {

	 console.log("loading test");
    console.log(this.test_id);
	  this.authService.getTest(this.test_id)
      .subscribe(test => {
      
         this.test = test;
		 
		 //this.name=test.name;
		 this.duration_hour=test.duration_hour;
		  this.marks=test.marks;
		 this.question=test.question;
		  this.created_by=test.created_by;
		 console.log("test",this.test);
		// alert(this.name);
      });
	   
	}
   
   ngOnDestroy() {
	   
	  console.log("loading exasssssssssssm2");
	 this.paramsSubscription.unsubscribe();
   }

    sendtoAddTest( ) {
    
    console.log( this.data);
   
    this.router.navigate(['addexam'],  { queryParams: { special:   this.data } });
	   }


  async sendtoTest(test_id,t_name,marks,negativemarks,duration_hour,duration_minute) {


  const loading = await this.loadingController.create({
      spinner:"bubbles",
      duration: 500,
      message: 'Please wait...',
      translucent: true,
      cssClass: 'custom-class custom-loading'
    });
// alert(test_id);
	  
		 // alert(r);
         
		//console.log("token",r);
		var data = JSON.stringify({"test_id":test_id});
		this.authService.mm(data)
		
		
      .subscribe(res =>
	{
		  
		  	  console.log("rgggggggggges");
		  	  console.log(res);
		   
			//alert("res");
		  
        if (!res.Error) {
    


      window.localStorage.removeItem("res");

    window.localStorage.setItem("res",res.attempt_id);
//alert("146");

		//this.storage.set("res",res.attempt_id);
		//alert(res.attempt_id);
		
	
        }
      }, (err) => {
        console.log(err);
      });
	  
	   
     
	  //this.router.navigate(['instructions'],  { queryParams: { special: test_id, special1:t_name } });
	  //alert(test_id,t_name,marks,negativemarks);
    this.router.navigate(['showexam'],  { queryParams: { special: test_id, special1:t_name,special2: marks, special3:negativemarks,special4:duration_hour,special5:duration_minute} });
   
    return await loading.present();
	
 }


	toggle() {
    this.show = !this.show;

    // CHANGE THE NAME OF THE BUTTON.
    if(this.show)  
      this.buttonName = "Hide";
    else
      this.buttonName = "Show";
  }  

 
}
